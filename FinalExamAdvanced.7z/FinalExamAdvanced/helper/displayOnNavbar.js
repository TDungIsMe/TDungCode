function disPlayOnNavbar() {
    const loginBlock = document.getElementById(login-block)
    const notloginBlock = document.getElementById(not-login-block)

    const user = getUsers()
    if (user) {
        loginBlock.classList
      }
}