const products = [
    {
        id : 1,
        name: "Iphone 15 128GB",
        desc: "",
        price: 21490000,
        img: '../images/product1.jpg',
    },
    {
        id : 2,
        name: "Iphone 13 256GB",
        desc: "",
        price: 15490000,
        img: '../images/product2.avif',
    },
    {
        id : 3,
        name: "Iphone 13 256GB",
        desc: "",
        price: 15490000,
        img: '../images/product3.jpg',
    },
    {
        id : 4,
        name: "Iphone 13 256GB",
        desc: "",
        price: 15490000,
        img: '../images/product4.jpg',
    },
    {
        id : 5,
        name: "Iphone 13 256GB",
        desc: "",
        price: 15490000,
        img: '../images/product5.jpg',
    },
    {
        id : 6,
        name: "Iphone 13 256GB",
        desc: "",
        price: 15490000,
        img: '../images/product6.jpg',
    },
    {
        id : 7,
        name: "Iphone 13 256GB",
        desc: "",
        price: 15490000,
        img: '../images/product7.jpg',
    },
    {
        id : 8,
        name: "Iphone 13 256GB",
        desc: "",
        price: 15490000,
        img: '../images/product8.jpg',
    },
    {
        id : 9,
        name: "Iphone 13 256GB",
        desc: "",
        price: 15490000,
        img: '../images/product9.jpg',
    },
    {
        id : 10,
        name: "Iphone 13 256GB",
        desc: "",
        price: 15490000,
        img: '../images/product10.jpg',
    },
]


export default products